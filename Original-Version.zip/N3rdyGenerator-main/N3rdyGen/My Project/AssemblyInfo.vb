﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' As informações gerais sobre um assembly são controladas por
' conjunto de atributos. Altere estes valores de atributo para modificar as informações
' associada a um assembly.

' Revise os valores dos atributos do assembly

<Assembly: AssemblyTitle("N3rdy Generator")>
<Assembly: AssemblyDescription("Um gerador de contas de minecraft")>
<Assembly: AssemblyCompany("N3rdyDesigner.xyz")>
<Assembly: AssemblyProduct("N3rdy Generator")>
<Assembly: AssemblyCopyright("Copyright ©N3rdyDesigner.xyz  2020")>
<Assembly: AssemblyTrademark("N3rdyDesigner.xyz")>

<Assembly: ComVisible(False)>

'O GUID a seguir será destinado à ID de typelib se este projeto for exposto para COM
<Assembly: Guid("efa878b8-48ac-4a61-9d7f-dca9928ac838")>

' As informações da versão de um assembly consistem nos quatro valores a seguir:
'
'      Versão Principal
'      Versão Secundária 
'      Número da Versão
'      Revisão
'
' É possível especificar todos os valores ou usar como padrão os Números de Build e da Revisão
' usando o "*" como mostrado abaixo:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("0.0.0.1")>
<Assembly: AssemblyFileVersion("0.0.0.1")>
